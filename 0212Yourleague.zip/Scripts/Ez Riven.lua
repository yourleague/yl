if myHero.charName ~= "Riven" then return end
local Version = "1.3"
local AutoUpdate = true
local LastQ = 0
local Wrange = 260
local Rrange2 = 900
local RCasted = false
local LastSpell = 0
local Loaded = false
OrbWalkers = {}
LoadedOrb = nil
local RTIME = 0
local QCount = 0
local LastTiamat = 0

-- Script Status --
assert(load(Base64Decode("G0x1YVIAAQQEBAgAGZMNChoKAAAAAAAAAAAAAQIKAAAABgBAAEFAAAAdQAABBkBAAGUAAAAKQACBBkBAAGVAAAAKQICBHwCAAAQAAAAEBgAAAGNsYXNzAAQNAAAAU2NyaXB0U3RhdHVzAAQHAAAAX19pbml0AAQLAAAAU2VuZFVwZGF0ZQACAAAAAgAAAAgAAAACAAotAAAAhkBAAMaAQAAGwUAABwFBAkFBAQAdgQABRsFAAEcBwQKBgQEAXYEAAYbBQACHAUEDwcEBAJ2BAAHGwUAAxwHBAwECAgDdgQABBsJAAAcCQQRBQgIAHYIAARYBAgLdAAABnYAAAAqAAIAKQACFhgBDAMHAAgCdgAABCoCAhQqAw4aGAEQAx8BCAMfAwwHdAIAAnYAAAAqAgIeMQEQAAYEEAJ1AgAGGwEQA5QAAAJ1AAAEfAIAAFAAAAAQFAAAAaHdpZAAEDQAAAEJhc2U2NEVuY29kZQAECQAAAHRvc3RyaW5nAAQDAAAAb3MABAcAAABnZXRlbnYABBUAAABQUk9DRVNTT1JfSURFTlRJRklFUgAECQAAAFVTRVJOQU1FAAQNAAAAQ09NUFVURVJOQU1FAAQQAAAAUFJPQ0VTU09SX0xFVkVMAAQTAAAAUFJPQ0VTU09SX1JFVklTSU9OAAQEAAAAS2V5AAQHAAAAc29ja2V0AAQIAAAAcmVxdWlyZQAECgAAAGdhbWVTdGF0ZQAABAQAAAB0Y3AABAcAAABhc3NlcnQABAsAAABTZW5kVXBkYXRlAAMAAAAAAADwPwQUAAAAQWRkQnVnc3BsYXRDYWxsYmFjawABAAAACAAAAAgAAAAAAAMFAAAABQAAAAwAQACBQAAAHUCAAR8AgAACAAAABAsAAABTZW5kVXBkYXRlAAMAAAAAAAAAQAAAAAABAAAAAQAQAAAAQG9iZnVzY2F0ZWQubHVhAAUAAAAIAAAACAAAAAgAAAAIAAAACAAAAAAAAAABAAAABQAAAHNlbGYAAQAAAAAAEAAAAEBvYmZ1c2NhdGVkLmx1YQAtAAAAAwAAAAMAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAUAAAAFAAAABQAAAAUAAAAFAAAABQAAAAUAAAAFAAAABgAAAAYAAAAGAAAABgAAAAUAAAADAAAAAwAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAcAAAAIAAAACAAAAAgAAAAIAAAAAgAAAAUAAABzZWxmAAAAAAAtAAAAAgAAAGEAAAAAAC0AAAABAAAABQAAAF9FTlYACQAAAA4AAAACAA0XAAAAhwBAAIxAQAEBgQAAQcEAAJ1AAAKHAEAAjABBAQFBAQBHgUEAgcEBAMcBQgABwgEAQAKAAIHCAQDGQkIAx4LCBQHDAgAWAQMCnUCAAYcAQACMAEMBnUAAAR8AgAANAAAABAQAAAB0Y3AABAgAAABjb25uZWN0AAQRAAAAc2NyaXB0c3RhdHVzLm5ldAADAAAAAAAAVEAEBQAAAHNlbmQABAsAAABHRVQgL3N5bmMtAAQEAAAAS2V5AAQCAAAALQAEBQAAAGh3aWQABAcAAABteUhlcm8ABAkAAABjaGFyTmFtZQAEJgAAACBIVFRQLzEuMA0KSG9zdDogc2NyaXB0c3RhdHVzLm5ldA0KDQoABAYAAABjbG9zZQAAAAAAAQAAAAAAEAAAAEBvYmZ1c2NhdGVkLmx1YQAXAAAACgAAAAoAAAAKAAAACgAAAAoAAAALAAAACwAAAAsAAAALAAAADAAAAAwAAAANAAAADQAAAA0AAAAOAAAADgAAAA4AAAAOAAAACwAAAA4AAAAOAAAADgAAAA4AAAACAAAABQAAAHNlbGYAAAAAABcAAAACAAAAYQAAAAAAFwAAAAEAAAAFAAAAX0VOVgABAAAAAQAQAAAAQG9iZnVzY2F0ZWQubHVhAAoAAAABAAAAAQAAAAEAAAACAAAACAAAAAIAAAAJAAAADgAAAAkAAAAOAAAAAAAAAAEAAAAFAAAAX0VOVgA="), nil, "bt", _ENV))() ScriptStatus("TGJKINJKFKL") 
-- Script Status --

local serveradress = "raw.githubusercontent.com"
local scriptadress = "/HiranN/BoL/master"
local scriptname = "Ez Riven"
local scriptmsg = "<font color=\"#06CD51\"><b>[Ez Riven]</b></font>"
function CheckUpdate()
  local ServerVersionDATA = GetWebResult(serveradress , scriptadress.."/"..scriptname..".version")
  if ServerVersionDATA then
  local ServerVersion = tonumber(ServerVersionDATA)
  if ServerVersion then
  if ServerVersion > tonumber(Version) then
  print(scriptmsg.."<font color=\"#C2FDF3\"><b> Updating, don't press F9.</b></font>")
  DownloadUpdate()
  else
  print(scriptmsg.."<font color=\"#C2FDF3\"><b> You have the latest version.</b></font>")
  end
  else
  print(scriptmsg.."<font color=\"#C2FDF3\"><b> An error occured, while updating, please reload.</b></font>")
  end
  else
  print(scriptmsg.."<font color=\"#C2FDF3\"><b> Could not connect to update Server.</b></font>")
end
end

function DownloadUpdate()
  DownloadFile("http://"..serveradress..scriptadress.."/"..scriptname..".lua",SCRIPT_PATH..scriptname..".lua", function ()
  print(scriptmsg.."<font color=\"#C2FDF3\"><b> Updated, press 2x F9.</b></font>")
  end)
end


function OnLoad()
    Menu()
    SkinLoad()
    ts = TargetSelector(TARGET_LESS_CAST_PRIORITY, 900, DAMAGE_PHYSICAL)
    ts.name = "Riven"
    Menu:addTS(ts)
    enemyMinions = minionManager(MINION_ENEMY, 700, myHero, MINION_SORT_HEALTH_ASC)
    jungleMinions = minionManager(MINION_JUNGLE, 700, myHero, MINION_SORT_MAXHEALTH_DEC)
    PrintChat(scriptmsg.."<font color=\"#C2FDF3\"><b> Loaded Version: "..Version.."</b></font>")
    CheckUpdate()
    CheckSummoner()
    LoadTableOrbs()
    LoadOrb()
  ___GetInventorySlotItem = rawget(_G, "GetInventorySlotItem")
  _G.GetInventorySlotItem = GetSlotItem
  _G.ITEM_1 = 06
  _G.ITEM_2 = 07
  _G.ITEM_3 = 08
  _G.ITEM_4 = 09
  _G.ITEM_5 = 10
  _G.ITEM_6 = 11
  _G.ITEM_7 = 12
end

  function CheckSummoner()
  if myHero:GetSpellData(SUMMONER_1).name:find("summonerdot") then Ignite = SUMMONER_1 elseif myHero:GetSpellData(SUMMONER_2).name:find("summonerdot") then Ignite = SUMMONER_2 end
  if myHero:GetSpellData(SUMMONER_1).name:find("summonerflash") then Flash = SUMMONER_1 elseif myHero:GetSpellData(SUMMONER_2).name:find("summonerflash") then Flash = SUMMONER_2 end
  if myHero:GetSpellData(SUMMONER_1).name:find("summonerbar") then Heal = SUMMONER_1 elseif myHero:GetSpellData(SUMMONER_2).name:find("summonerbar") then Heal = SUMMONER_2 end
  if myHero:GetSpellData(SUMMONER_1).name:find("summonerheal") then Barrier = SUMMONER_1 elseif myHero:GetSpellData(SUMMONER_2).name:find("summonerheal") then Barrier = SUMMONER_2 end
  if myHero:GetSpellData(SUMMONER_1).name:find("summonercleanse") then Cleanse = SUMMONER_1 elseif myHero:GetSpellData(SUMMONER_2).name:find("summonercleanse") then Cleanse = SUMMONER_2 end
  end

  function HaveBuffs(unit, buffs)
        for i = 1, unit.buffCount, 1 do      
            local buff = unit:getBuff(i) 
            if buff.valid and buff.type == buffs then
                return true            
            end                    
        end
  end

  ItemNames     = {
  [3144]        = "BilgewaterCutlass",
  [3153]        = "ItemSwordOfFeastAndFamine",
  [3405]        = "TrinketSweeperLvl1",
  [3166]        = "TrinketTotemLvl1",
  [3361]        = "TrinketTotemLvl3",
  [3362]        = "TrinketTotemLvl4",
  [2003]        = "RegenerationPotion",
  [3146]        = "HextechGunblade",
  [3187]        = "HextechSweeper",
  [3364]        = "TrinketSweeperLvl3",
  [3074]        = "ItemTiamatCleave",
  [3077]        = "ItemTiamatCleave",
  [3340]        = "TrinketTotemLvl1",
  [3090]        = "ZhonyasHourglass",
  [3142]        = "YoumusBlade",
  [3157]        = "ZhonyasHourglass",
  [3350]        = "TrinketTotemLvl2",
  [3140]        = "QuicksilverSash",
  [3139]        = "ItemMercurial",
  }

  function CastItems()
  if Target ~= nil then
  if Menu.items.UseBRK then
  local slot = GetInventorySlotItem(3153)
  if Target ~= nil and ValidTarget(Target) and not Target.dead and slot ~= nil and myHero:CanUseSpell(slot) == READY and GetDistance(Target) <= 450 then
  CastSpell(slot, Target)
  end
  end

  if Menu.items.UseHydra then
  local slot = GetInventorySlotItem(3074)
  if Target ~= nil and ValidTarget(Target) and not Target.dead and slot ~= nil and myHero:CanUseSpell(slot) == READY and GetDistance(Target) <= 185 then
  CastSpell(slot)
  end
  end

  if Menu.items.UseQSS then

  if GetInventorySlotItem(3139) ~= nil then 
  local slot = GetInventorySlotItem(3139) 
  elseif GetInventorySlotItem(3140) ~= nil then 
  local slot = GetInventorySlotItem(3140) end 

  local buffsList = 6,8,9,11,20,21,23,24,29,30,31
  if Target ~= nil and ValidTarget(Target) and not Target.dead and slot ~= nil and myHero:CanUseSpell(slot) == READY and GetDistance(Target) <= 600 and HaveBuffs(myHero, buffsList) then
  CastSpell(slot)
  end
  end

  if Menu.items.UseYoumu then
  local slot = GetInventorySlotItem(3142)
  if Target ~= nil and ValidTarget(Target) and not Target.dead and slot ~= nil and myHero:CanUseSpell(slot) == READY then
  CastSpell(slot)
  end
  end

  if Menu.items.UseZhonya then
  local slot = GetInventorySlotItem(3157)
  if myHero.health <= (myHero.maxHealth * Menu.items.ZhonyaAmount / 100) and slot ~= nil and myHero:CanUseSpell(slot) == READY and CountEnemyHeroInRange(900) >= 1 then CastSpell(slot) end
  end
  end
  end

  function GetSlotItem(id, unit)
  
  unit = unit or myHero

  if (not ItemNames[id]) then
  return ___GetInventorySlotItem(id, unit)
  end

  local name  = ItemNames[id]
  
  for slot = ITEM_1, ITEM_7 do
  local item = unit:GetSpellData(slot).name
  if ((#item > 0) and (item:lower() == name:lower())) then
  return slot
  end
  end
  end

Sequence = {1,3,2,1,1,4,1,3,1,3,4,3,3,2,2,4,2,}

function LoadTableOrbs()
  if _G.Reborn_Loaded or _G.Reborn_Initialised or _G.AutoCarry ~= nil then
  table.insert(OrbWalkers, "SAC")
  end
  if _G.MMA_IsLoaded then
  table.insert(OrbWalkers, "MMA")
  end
  if _G._Pewalk then
  table.insert(OrbWalkers, "Pewalk")
  end
  if FileExist(LIB_PATH .. "/Nebelwolfi's Orb Walker.lua") then
  table.insert(OrbWalkers, "NOW")
  end
  if FileExist(LIB_PATH .. "/Big Fat Orbwalker.lua") then
  table.insert(OrbWalkers, "Big Fat Walk")
  end
  if FileExist(LIB_PATH .. "/SOW.lua") then
  table.insert(OrbWalkers, "SOW")
  end
  if FileExist(LIB_PATH .. "/SxOrbWalk.lua") then
  table.insert(OrbWalkers, "SxOrbWalk")
  end
  if #OrbWalkers > 0 then
  Menu:addSubMenu("Orbwalkers", "Orbwalkers")
  Menu:addSubMenu("Keys", "Keys")
  Menu.Orbwalkers:addParam("Orbwalker", "OrbWalker", SCRIPT_PARAM_LIST, 1, OrbWalkers)
  Menu.Keys:addParam("info", "Detecting keys from: "..OrbWalkers[Menu.Orbwalkers.Orbwalker], SCRIPT_PARAM_INFO, "")
  local OrbAlr = false
    Menu.Orbwalkers:setCallback("Orbwalker", function(value) 
    if OrbAlr then return end
    OrbAlr = true
  Menu.Orbwalkers:addParam("info", "Press F9 2x to load your selected Orbwalker.", SCRIPT_PARAM_INFO, "")
    SendMsg("Press F9 2x to load your selected Orbwalker")
    end)
  end
end

function LoadOrb()
  if OrbWalkers[Menu.Orbwalkers.Orbwalker] == "SAC" then
  LoadedOrb = "Sac"
  TIMETOSACLOAD = false
  DelayAction(function() TIMETOSACLOAD = true end,15)
  elseif OrbWalkers[Menu.Orbwalkers.Orbwalker] == "MMA" then
  LoadedOrb = "Mma"
  elseif OrbWalkers[Menu.Orbwalkers.Orbwalker] == "Pewalk" then
  LoadedOrb = "Pewalk"
  elseif OrbWalkers[Menu.Orbwalkers.Orbwalker] == "NOW" then
  LoadedOrb = "Now"
  require "Nebelwolfi's Orb Walker"
  _G.NOWi = NebelwolfisOrbWalkerClass()
    Menu.Orbwalkers:addSubMenu("NOW", "NOW")
    _G.NebelwolfisOrbWalkerClass(Menu.Orbwalkers.NOW) 
  elseif OrbWalkers[Menu.Orbwalkers.Orbwalker] == "Big Fat Walk" then
  LoadedOrb = "Big"
  require "Big Fat Orbwalker"
  elseif OrbWalkers[Menu.Orbwalkers.Orbwalker] == "SOW" then
  LoadedOrb = "Sow"
  require "SOW"
    Menu.Orbwalkers:addSubMenu("SOW", "SOW")
    _G.SOWi = SOW(_G.VP)
  SOW:LoadToMenu(Menu.Orbwalkers.SOW)
  elseif OrbWalkers[Menu.Orbwalkers.Orbwalker] == "SxOrbWalk" then
  LoadedOrb = "SxOrbWalk"
  require "SxOrbWalk"
    Menu.Orbwalkers:addSubMenu("SxOrbWalk", "SxOrbWalk")
  SxOrb:LoadToMenu(Menu.Orbwalkers.SxOrbWalk)
  end
end

function SendMsg(msg)
  PrintChat(scriptmsg.."<font color=\"#C2FDF3\"><b> "..msg..".</b></font>")
end

function Keys()
  if LoadedOrb == "Sac" and TIMETOSACLOAD then
  if _G.AutoCarry.Keys.AutoCarry then return "Combo" end
  if _G.AutoCarry.Keys.MixedMode then return "Harass" end
  if _G.AutoCarry.Keys.LaneClear then return "Laneclear" end
  if _G.AutoCarry.Keys.LastHit then return "Lasthit" end
  elseif LoadedOrb == "Mma" then
  if _G.MMA_IsOrbwalking() then return "Combo" end
  if _G.MMA_IsDualCarrying() then return "Harass" end
  if _G.MMA_IsLaneClearing() then return "Laneclear" end
  if _G.MMA_IsLastHitting() then return "Lasthit" end
  elseif LoadedOrb == "Pewalk" then
  if _G._Pewalk.GetActiveMode().Carry then return "Combo" end
  if _G._Pewalk.GetActiveMode().Mixed then return "Harass" end
  if _G._Pewalk.GetActiveMode().LaneClear then return "Laneclear" end
  if _G._Pewalk.GetActiveMode().Farm then return "Lasthit" end
  elseif LoadedOrb == "Now" then
  if _G.NOWi.Config.k.Combo then return "Combo" end
  if _G.NOWi.Config.k.Harass then return "Harass" end
  if _G.NOWi.Config.k.LaneClear then return "Laneclear" end
  if _G.NOWi.Config.k.LastHit then return "Lasthit" end
  elseif LoadedOrb == "Big" then
  if _G["BigFatOrb_Mode"] == "Combo" then return "Combo" end
  if _G["BigFatOrb_Mode"] == "Harass" then return "Harass" end
  if _G["BigFatOrb_Mode"] == "LaneClear" then return "Laneclear" end
  if _G["BigFatOrb_Mode"] == "LastHit" then return "Lasthit" end
  elseif LoadedOrb == "Sow" then
  if _G.SOWi.Menu.Mode0 then return "Combo" end
  if _G.SOWi.Menu.Mode1 then return "Harass" end
  if _G.SOWi.Menu.Mode2 then return "Laneclear" end
  if _G.SOWi.Menu.Mode3 then return "Lasthit" end
  elseif LoadedOrb == "SxOrbWalk" then
  if _G.SxOrb.isFight then return "Combo" end
  if _G.SxOrb.isHarass then return "Harass" end
  if _G.SxOrb.isLaneClear then return "Laneclear" end
  if _G.SxOrb.isLastHit then return "Lasthit" end
  end
end

function OnTick()
  Checks()
  autoW()

  if Keys() == "Combo" then Combo() CastItems() end
  if Keys() == "Laneclear" then LaneJung() end
  if Menu.fleeKey then Flee() end
  if VIP_USER then
  if Menu.AutoLvL.On and os.clock() - LastSpell >= 0.5 then
  LastSpell = os.clock()  
  DelayAction(function() autoLevelSetSequence(Sequence) end,2)
  end
  end

end

  _G.LevelSpell = function(id)
  if (string.find(GetGameVersion(), 'Releases/6.3') ~= nil) and Menu.AutoLvL.On then
  msg = "<font color=\"#06CD51\"><b>[Ez Riven]</b></font>"
  local offsets = { 
  [_Q] = 0x8A,
  [_W] = 0xE1,
  [_E] = 0x23,
  [_R] = 0x14,
  }
  local p = CLoLPacket(0x00E7)
  p.vTable = 0xF9C650
  p:EncodeF(myHero.networkID)
  p:Encode1(0x9B)
  p:Encode1(offsets[id])
  for i = 1, 4 do p:Encode1(0x2D) end
  for i = 1, 4 do p:Encode1(0x6A) end
  for i = 1, 4 do p:Encode1(0x0F) end
  SendPacket(p)
  if id == _Q then PrintChat(msg.."<font color=\"#01cc9c\"><b> Auto Leveler: </b></font>".."<font color=\"#b71c1c\"><b>Q</b></font>") end
  if id == _W then PrintChat(msg.."<font color=\"#01cc9c\"><b> Auto Leveler: </b></font>".."<font color=\"#b71c1c\"><b>W</b></font>") end
  if id == _E then PrintChat(msg.."<font color=\"#01cc9c\"><b> Auto Leveler: </b></font>".."<font color=\"#b71c1c\"><b>E</b></font>") end
  if id == _R then PrintChat(msg.."<font color=\"#01cc9c\"><b> Auto Leveler: </b></font>".."<font color=\"#b71c1c\"><b>R</b></font>") end
  end
  end

  function Menu()

    Menu = scriptConfig("Ez Riven", "EZRiven")

    Menu:addSubMenu("Combo", "c")
      Menu.c:addParam("useQ", "Use Q", SCRIPT_PARAM_ONOFF, true)
      Menu.c:addParam("useW", "Use W", SCRIPT_PARAM_ONOFF, true)
      Menu.c:addParam("useE", "Use E", SCRIPT_PARAM_ONOFF, true)
      Menu.c:addParam("useR", "Use R", SCRIPT_PARAM_ONOFF, true)
      Menu.c:addParam("combos", "Combo Mode", SCRIPT_PARAM_LIST, 1, {"Basic", "E-Q-Q-W-Q", "Burst"})

    Menu:addSubMenu("LaneClear/JungleClear", "jc")
      Menu.jc:addParam("useQ", "Use Q", SCRIPT_PARAM_ONOFF, true)
      Menu.jc:addParam("useW", "Use W", SCRIPT_PARAM_ONOFF, true)
      Menu.jc:addParam("useE", "Use E", SCRIPT_PARAM_ONOFF, true)

    Menu:addSubMenu("Auto W", "autoW")
      Menu.autoW:addParam("W", "Use Auto W",SCRIPT_PARAM_ONOFF, true)
      Menu.autoW:addParam("S", "x Enemies for Auto W", SCRIPT_PARAM_SLICE, 2, 0, 5, 0)

    Menu:addSubMenu("Items Settings", "items")
      Menu.items:addParam("Use", "Use Items", SCRIPT_PARAM_ONOFF, true) 
      Menu.items:addParam("UseBRK", "Use BRK", SCRIPT_PARAM_ONOFF, true) 
      Menu.items:addParam("UseHydra", "Use Hydra", SCRIPT_PARAM_ONOFF, true) 
      Menu.items:addParam("UseYoumu", "Use Youmus", SCRIPT_PARAM_ONOFF, true) 
      Menu.items:addParam("UseQSS", "Use QSS", SCRIPT_PARAM_ONOFF, true)
      Menu.items:addParam("UseZhonya", "Use Zhonyas", SCRIPT_PARAM_ONOFF, true)
      Menu.items:addParam("ZhonyaAmount", "Zhonya %", SCRIPT_PARAM_SLICE, 15, 0, 100, 0)

    Menu:addSubMenu("Draws Settings", "draws")
      Menu.draws:addParam("CDTracker", "Use CD Tracker", SCRIPT_PARAM_ONOFF, true) 

    Menu:addSubMenu("Emote Cancel", "emoteCancel")
      Menu.emoteCancel:addParam("emoteC", "Choose Emote", SCRIPT_PARAM_LIST, 1, {"Dance", "Taunt", "Laugh", "Joke"})

    Menu:addSubMenu("Skin Changer", "skin")

    if VIP_USER then
    Menu:addSubMenu("Auto Leveler", "AutoLvL")
    Menu.AutoLvL:addParam("On", "Use Auto Leveler", SCRIPT_PARAM_ONOFF, false)
    end
    Menu:addParam("fleeKey", "Flee Key", SCRIPT_PARAM_ONKEYDOWN, false, string.byte("T"))

    Menu:addSubMenu("Language Support","language")
    Menu.language:addParam("languageChoose", "Choose Your Language", SCRIPT_PARAM_LIST, 1, {"English", "German", "French", "Portuguese"})
    SwitchMenuLanguage(Menu.language.languageChoose)
    Menu.language:setCallback("languageChoose", function(lang)    
    SwitchMenuLanguage(lang)
    end)
end

Language =
{
[1] = { --English
["UseQ"] = "Use Q",
["UseW"] = "Use W",
["UseE"] = "Use E",
["UseR"] = "Use R",
["ComboMode"] = "Combo Mode",
["AutoW"] = "Use Auto W",
["AutoWEnemies"] = "x Enemies for Auto W",
["UseItems"] = "Use Items",
["BRK"] = "Use BRK",
["Hydra"] = "Use Hydra",
["Youmus"] = "Use Youmus",
["QSS"] = "Use QSS",
["Zhonyas"] = "Use Zhonyas",
["CDTracker"] = "Use CD Tracker",
["ChooseEmote"] = "Choose Emote",
["AutoLeveler"] = "Use Auto Leveler",
["FleeKey"] = "Flee Key",},
[2] = { --GERMAN
["UseQ"] = "Nutze Q",
["UseW"] = "Nutze W",
["UseE"] = "Nutze E",
["UseR"] = "Nutze R",
["ComboMode"] = "Combo Mode",
["AutoW"] = "Nutze Auto W",
["AutoWEnemies"] = "x Gegner für Auto W",
["UseItems"] = "Nutze Items",
["BRK"] = "Nutze BRK",
["Hydra"] = "Nutze Hydra",
["Youmus"] = "Nutze Youmus",
["QSS"] = "Nutze QSS",
["Zhonyas"] = "Nutze Zhonyas",
["CDTracker"] = "Nutze CD Tracker",
["ChooseEmote"] = "Waehle Emote",
["AutoLeveler"] = "Nutze Auto Leveler",
["FleeKey"] = "Flee Key",},
[3] = { --French
["UseQ"] = "Utiliser A",
["UseW"] = "Utiliser Z",
["UseE"] = "Utiliser E",
["UseR"] = "Utiliser R",
["ComboMode"] = "Mode Combo",
["AutoW"] = "Utiliser Auto W",
["AutoWEnemies"] = "x Enemies pour Auto W",
["UseItems"] = "Utiliser les Items",
["BRK"] = "Utiliser BRK",
["Hydra"] = "Utiliser Hydra",
["Youmus"] = "Utiliser Youmus",
["QSS"] = "Utiliser QSS",
["Zhonyas"] = "Utiliser Zhonyas",
["CDTracker"] = "Utiliser CD Tracker",
["ChooseEmote"] = "Choississez l'Emote",
["AutoLeveler"] = "Utiliser Auto Leveler",
["FleeKey"] = "Touche pour fuir",},
[4] = { --Portuguese
["UseQ"] = "Usar Q",
["UseW"] = "Usar W",
["UseE"] = "Usar E",
["UseR"] = "Usar R",
["ComboMode"] = "Modo do Combo",
["AutoW"] = "Usar Auto W",
["AutoWEnemies"] = "x Inimigos para Auto W",
["UseItems"] = "Usar Items",
["BRK"] = "Usar BRK",
["Hydra"] = "Usar Hydra",
["Youmus"] = "Usar Youmus",
["QSS"] = "Usar QSS",
["Zhonyas"] = "Usar Zhonyas",
["CDTracker"] = "Usar CD Tracker",
["ChooseEmote"] = "Escolher Emote",
["AutoLeveler"] = "Usar Auto Leveler",
["FleeKey"] = "Flee Key",},
}

function SwitchMenuLanguage(which)
    Menu.c:modifyParam("useQ", "text", Language[which].UseQ)
    Menu.c:modifyParam("useW", "text", Language[which].UseW)
    Menu.c:modifyParam("useE", "text", Language[which].UseE)
    Menu.c:modifyParam("useR", "text", Language[which].UseR)
    Menu.c:modifyParam("combos", "text", Language[which].ComboMode)
    Menu.jc:modifyParam("useQ", "text", Language[which].UseQ)
    Menu.jc:modifyParam("useW", "text", Language[which].UseW)
    Menu.jc:modifyParam("useE", "text", Language[which].UseE)
    Menu.autoW:modifyParam("W", "text", Language[which].AutoW)
    Menu.autoW:modifyParam("S", "text", Language[which].AutoWEnemies)
    Menu.items:modifyParam("Use", "text", Language[which].UseItems)
    Menu.items:modifyParam("UseBRK", "text", Language[which].BRK)
    Menu.items:modifyParam("UseHydra", "text", Language[which].Hydra)
    Menu.items:modifyParam("UseYoumu", "text", Language[which].Youmus)
    Menu.items:modifyParam("UseQSS", "text", Language[which].QSS)
    Menu.items:modifyParam("UseZhonya", "text", Language[which].Zhonyas)
    Menu.draws:modifyParam("CDTracker", "text", Language[which].CDTracker)
    Menu.emoteCancel:modifyParam("emoteC", "text", Language[which].ChooseEmote)
    Menu.AutoLvL:modifyParam("On", "text", Language[which].AutoLeveler)
    Menu:modifyParam("fleeKey", "text", Language[which].FleeKey)
end

function SkinLoad()
    Menu.skin:addParam('changeSkin', 'Change Skin', SCRIPT_PARAM_ONOFF, false);
    Menu.skin:setCallback('changeSkin', function(nV)
        if (nV) then
            SetSkin(myHero, Menu.skin.skinID)
        else
            SetSkin(myHero, -1)
        end
    end)
    Menu.skin:addParam('skinID', 'Skin', SCRIPT_PARAM_LIST, 1, {"Redeemed", "Crimson Elite", "Battle Bunny", "Championship", "Dragonblade", "Arcade", "Classic"})
    Menu.skin:setCallback('skinID', function(nV)
        if (Menu.skin.changeSkin) then
            SetSkin(myHero, nV)
        end
    end)
    
    if (Menu.skin.changeSkin) then
        SetSkin(myHero, Menu.skin.skinID)
    end
end

function LaneJung()
    enemyMinions:update()
    jungleMinions:update()
    for _, minion in pairs(enemyMinions.objects) do
      if Menu.jc.useQ then CastQAA(minion) end
      if Menu.jc.useW then CastW(minion) end
    end
    for _, minion in pairs(jungleMinions.objects) do
      if Menu.jc.useQ then CastQAA(minion) end
      if Menu.jc.useE then 
        DelayAction(function ()
          CastE(minion)
        end,0.05) 
      end
      if Menu.jc.useW then 
        DelayAction(function ()
          CastW(minion)
        end,0.05) 
      end
    end
 end

function Combo()
  if Menu.c.combos == 1 then Combo1() end
  if Menu.c.combos == 2 then Combo2() end
  if Menu.c.combos == 3 then Combo3() end
end


function Combo1()
    if Target ~= nil then
      Checks()

    if Menu.c.useE and Menu.c.useR then
      CastSpell(_E,mousePos.x, mousePos.z)
      CastR(Target)
    end

    if Menu.c.useE then
      CastSpell(_E, mousePos.x, mousePos.z)
    end

    if Menu.c.useR then
      CastR(Target)
    end

    if Menu.c.useW then 
      CastW(Target) 
    end

    if Menu.c.useQ then 
      CastQAA(Target) 
    end
    
  end
end

function Combo2()
  if Target ~= nil then
    Checks()

    if Menu.c.useQ then 
      CastQAA(Target) 
    end

    if Menu.c.useW then
      if Wready then
        if QCount >= 2 then
          CastW2(Target)
        end
      end
    end

    if Menu.c.useE and Menu.c.useR then
      CastE(Target)
      CastSpell(_R)
    end

    if Menu.c.useR then
      CastR(Target)
    end
  end
end

--Burst Combo Ghostblade-E-R-(F)-W-AA-Hydra-Q-AA-Q-AA-R-Q3
function Combo3()
  local Q2Casted = false
 if Target ~= nil then
    Checks()
    if Menu.c.useE and Menu.c.useR and RCasted == false then
      CastSpell(_E,mousePos.x, mousePos.z)
      CastSpell(_R)
    end

    if Menu.c.useW then 
      CastW2(Target) 
    end
    -- AA zwischen W & Q1
    -- + Hydra Cast
    -- x2
    if Menu.c.useQ and QCount == 0 then 
      CastQAA(Target)
    end

    if Menu.c.useQ and QCount == 1 then 
      CastQAA(Target)
      Q2Casted = true
    end

    if Menu.c.useR and Q2Casted == true then 
      CastSpell(_R, Target.x, Target.z)
      Q2Casted = false
    end

    if Menu.c.useQ and QCount == 2 then 
      CastQAA(Target)
    end
  end
end

function autoW()
  Checks()
    if Menu.autoW.W and CountEnemyHeroInRange(Wrange) >= Menu.autoW.S then
      CastSpell(_W)
    end
  end

function Flee()
    if Menu.fleeKey then
    myHero:MoveTo(mousePos.x, mousePos.z)
    CastSpell(_Q, mousePos.x, mousePos.z)
    CastSpell(_E, mousePos.x, mousePos.z)
    end
end

function CastQAA(target)
    if ValidTarget(target) and myHero:CanUseSpell(_Q) == READY and GetTickCount() > LastQ + 760 then
    CastSpell(_Q, target.x, target.z)
    end
end

function CastW(target)
    if ValidTarget(target) and GetDistance(target) <= 255 and myHero:CanUseSpell(_W) == READY and myHero:GetSpellData(_Q).currentCd > 0.5 then
    CastSpell(_W)
    end
end

function CastW2(target)
    if ValidTarget(target) and GetDistance(target) <= 255 and myHero:CanUseSpell(_W) == READY then
    CastSpell(_W)
    end
end

function CastE(target)
    if ValidTarget(target) and myHero:GetSpellData(_Q).currentCd > 0.5 then
    CastSpell(_E, target.x, target.z)
    end
end

function CastR(target)
    if ValidTarget(target) then
    if not UltOn() and myHero:CanUseSpell(_R) == READY then CastSpell(_R) end
    if UltOn() then
    if rDmg(target) >= target.health or RTIME-os.clock() <= -11 then
    if GetDistance(target) <= 1000 and myHero:CanUseSpell(_R) == READY then 
    CastSpell(_R, Target.x, Target.z) 
    end
    end
    end
end
end

function rDmg(unit)
  local Lvl = myHero:GetSpellData(_R).level
  if Lvl < 1 then return 0 end
  local DMGCALC = 0
  bad = myHero.addDamage*(1.2)
  ad = myHero.totalDamage+bad
  local hpercent = unit.health/unit.maxHealth
  if hpercent <= 0.25 then
  DMGCALC = 120*myHero:GetSpellData(_R).level+120+1.8*bad
  else
  DMGCALC = (40*myHero:GetSpellData(_R).level+40+0.6*bad) * (hpercent)*(-2.67) + 3.67
  end
  return myHero:CalcDamage(unit, DMGCALC)
  end

function OnUpdateBuff(unit,buff)
  if unit and buff and unit.isMe then
    if buff.name=="RivenTriCleave" then 
      QCount = QCount + 1
    end
  end
end

function Checks()
    ts:update()
    Qready = (myHero:CanUseSpell(_Q) == READY)
    Wready = (myHero:CanUseSpell(_W) == READY)
    Eready = (myHero:CanUseSpell(_E) == READY)
    Rready = (myHero:CanUseSpell(_R) == READY)
    if ts.target and ts.target ~= nil and ValidTarget(ts.target) and not ts.target.dead then
    Target = ts.target
    else Target = nil
    end
end

function UltOn()
  if RCasted then return true else return false end
end

function OnDraw()
  if Menu.draws.CDTracker then DrawCD() end
end

function GetHPBarPos(enemy)
  enemy.barData = {PercentageOffset = {x = -0.05, y = 0}}--GetEnemyBarData()
  local barPos = GetUnitHPBarPos(enemy)
  local barPosOffset = GetUnitHPBarOffset(enemy)
  local barOffset = { x = enemy.barData.PercentageOffset.x, y = enemy.barData.PercentageOffset.y }
  local barPosPercentageOffset = { x = enemy.barData.PercentageOffset.x, y = enemy.barData.PercentageOffset.y }
  local BarPosOffsetX = 171
  local BarPosOffsetY = 46
  local CorrectionY = 39
  local StartHpPos = 31

  barPos.x = math.floor(barPos.x + (barPosOffset.x - 0.5 + barPosPercentageOffset.x) * BarPosOffsetX + StartHpPos)
  barPos.y = math.floor(barPos.y + (barPosOffset.y - 0.5 + barPosPercentageOffset.y) * BarPosOffsetY + CorrectionY)

  local StartPos = Vector(barPos.x , barPos.y, 0)
  local EndPos = Vector(barPos.x + 108 , barPos.y , 0)
  return Vector(StartPos.x, StartPos.y, 0), Vector(EndPos.x, EndPos.y, 0)
end

function DrawCD()
  for i = 1, heroManager.iCount, 1 do
    local champ = heroManager:getHero(i)
    if champ ~= nil and champ ~= myHero and champ.visible and champ.dead == false then
      local barPos = GetHPBarPos(champ)
      if OnScreen(barPos.x, barPos.y) then
        local cd = {}
        cd[0] = math.ceil(champ:GetSpellData(SPELL_1).currentCd)
        cd[1] = math.ceil(champ:GetSpellData(SPELL_2).currentCd)
        cd[2] = math.ceil(champ:GetSpellData(SPELL_3).currentCd)
        cd[3] = math.ceil(champ:GetSpellData(SPELL_4).currentCd)
        
        local spellColor = {}
        spellColor[0] = 0xBBFFD700;
        spellColor[1] = 0xBBFFD700;
        spellColor[2] = 0xBBFFD700;
        spellColor[3] = 0xBBFFD700;
                     
        if cd[0] == nil or cd[0] == 0 then cd[0] = "Q" spellColor[0] = 0xBBFFFFFF end
        if cd[1] == nil or cd[1] == 0 then cd[1] = "W" spellColor[1] = 0xBBFFFFFF end
        if cd[2] == nil or cd[2] == 0 then cd[2] = "E" spellColor[2] = 0xBBFFFFFF end
        if cd[3] == nil or cd[3] == 0 then cd[3] = "R" spellColor[3] = 0xBBFFFFFF end
        
        if champ:GetSpellData(SPELL_1).level == 0 then spellColor[0] = 0xBBFF0000 end
        if champ:GetSpellData(SPELL_2).level == 0 then spellColor[1] = 0xBBFF0000 end
        if champ:GetSpellData(SPELL_3).level == 0 then spellColor[2] = 0xBBFF0000 end
        if champ:GetSpellData(SPELL_4).level == 0 then spellColor[3] = 0xBBFF0000 end
        DrawRectangle(barPos.x-6, barPos.y-40, 80, 15, 0xBB202020)
        DrawText("[" .. cd[0] .. "]" ,12, barPos.x-5+2, barPos.y-40, spellColor[0])
        DrawText("[" .. cd[1] .. "]", 12, barPos.x+15+2, barPos.y-40, spellColor[1])
        DrawText("[" .. cd[2] .. "]", 12, barPos.x+35+2, barPos.y-40, spellColor[2])
        DrawText("[" .. cd[3] .. "]", 12, barPos.x+54+2, barPos.y-40, spellColor[3])
      end
    end
  end
end

function OnApplyBuff(unit, source, buff)
  if unit and buff and unit == myHero and buff.name == "RivenFengShuiEngine" then RCasted = true RTIME = os.clock() end
end

function OnRemoveBuff(unit, buff)
  if unit and buff and unit == myHero and buff.name == "rivenwindslashready" then RCasted = false RTIME = 0 end
  if unit and buff and unit.isMe then
    if buff.name == "RivenTriCleave" then 
      QCount = 0  
    end
  end
end

UseEList = {
  ["RocketGrabMissile"] = true, ["AhriSeduce"] = true, ["BandageToss"] = true, ["FlashFrostSpell"] = true, ["InfernalGuardian"] = true, ["EnchantedCrystalArrow"] = true,
  ["AzirR"] = true, ["BrandBlaze"] = true, ["BraumR"] = true, ["CassiopeiaPetrifyingGaze"] = true, ["DravenRCast"] = true, ["EliseHumanE"] = true,
  ["EzrealTrueshotBarrage"] = true, ["FizzMarinerDoom"] = true, ["GragasR"] = true, ["GragasE"] = true, ["JinxR"] = true, ["LeblancSoulShackle"] = true,
    ["LeonaSolarFlare"] = true, ["LuxMaliceCannon"] = true, ["LuxLightBinding"] = true, ["DarkBindingMissile"] = true, ["NamiQ"] = true, ["NautilusAnchorDrag"] = true,
  ["OrianaDetonateCommand"] = true, ["rivenizunablade"] = true, ["RumbleCarpetBomb"] = true, ["SejuaniGlacialPrisonCast"] = true, ["ShenShadowDash"] = true, ["SonaCrescendo"] = true,
  ["SwainShadowGrasp"] = true, ["ThreshQ"] = true, ["ThreshE"] = true, ["VarusR"] = true, ["VelKozE"] = true, ["VelKozR"] = true,
    ["ZiggsR"] = true, ["ZyraGraspingRoots"] = true, ["ZyraBrambleZone"] = true,
}


function OrbAttack(enemy)
 
  if Mode == "A" then
  --"A": Try Attack once and wait until next AA
    LastAATry = os.clock()
  end
  
  LastMove = os.clock()
  myHero:Attack(enemy)
end

function OnAnimation(unit, animation)
  if unit then
  --[[if animation:find("Attack") and os.clock()-GetLatency()/2000 > LastQ+0.1 and os.clock()-GetLatency()/2000 > LastTiamat+0.1 then
  --Splash damage of Q and using Tiamat also be detected by "BasicAttack"
  --So you have to check when you use Q and Tiamat lastly
  --AA starts (Wind up ~ )
  LastAATry = os.clock()-GetLatency()/2000
  LastAAStart = os.clock()-GetLatency()/2000
  -- something else
  end]]
  if unit.isMe then
  if animation == "Spell1a" or animation == "Spell1b" or animation == "Spell1c" then
  if Menu.fleeKey then return end
  if Keys() == "Combo" then if not ValidTarget(Target, 210) then return end end
  if Keys() == "Laneclear" then 
  for _, Minions in pairs(minionManager(MINION_ENEMY, 210).objects) do
  if not ValidTarget(Minions, 210) then return end end end
  if animation == "Spell1a" or animation == "Spell1b" then
  DelayAction(function() Emote() ResetAAs() end, 0.291-GetLatency()/1000)
  LastQ = GetTickCount()
  elseif animation == "Spell1c" then
  DelayAction(function() Emote() ResetAAs() end, 0.401-GetLatency()/1000)
  LastQ = GetTickCount()
  end
  end
  end
  end
end

function Emote()
  DoEmote(Menu.emoteCancel.emoteC-1)
end

function ResetAAs()
  if LoadedOrb == "Sac" and TIMETOSACLOAD then
  _G.AutoCarry.Orbwalker:ResetAttackTimer()
  elseif LoadedOrb == "Mma" then
  _G.MMA_ResetAutoAttack()
  elseif LoadedOrb == "Pewalk" then
  
  elseif LoadedOrb == "Now" then
  _G.NebelwolfisOrbWalker:ResetAA()
  elseif LoadedOrb == "Big" then
  
  elseif LoadedOrb == "Sow" then
  _G.SOWi:resetAA()
  elseif LoadedOrb == "SxOrbWalk" then
  _G.SxOrb:ResetAA()
  end
end
